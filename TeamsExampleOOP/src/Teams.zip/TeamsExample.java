

public class TeamsExample {
    public static void main(String[] args) {

    }
}